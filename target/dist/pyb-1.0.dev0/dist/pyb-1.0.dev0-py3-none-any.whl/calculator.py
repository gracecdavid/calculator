# calculator.py

class Calculator:
    def add(self, a, b):
        return a + b
    
#if __name__== "__main__":
 #   calculator = Calculator()
  #  result = calculator.add(5,3)
   # print("Addition: {result}")


